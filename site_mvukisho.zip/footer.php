<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Document</title>
</head>
<body>
    <section class="footer">
    <p>Mention légale</p>
    <a href="./connexion.php" class="connexion"><p>connexion</p></a>
    <a href="https://www.facebook.com/mvukisho"><i class='bx bxl-facebook-circle'></i></a>
    <a href="https://www.instagram.com/mym_comores/#"><i class='bx bxl-instagram-alt' ></i></a>
    </section>
   
</body>
</html>