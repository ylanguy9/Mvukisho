<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css" />
    <title>Document</title>
</head>
<body>
     <?php  include "./header.php"; ?>


     <p>Page en cours d'actualisation</p> <br>
     <h1>Question fréquentes : </h1>
     <ul>
        <li class="question">Comment devenir membre</li>
        <p>L'adhésion se fait en plusieurs étapes: <br> 
            - être parrainé par un membre de Mvukisho <br>
            - entretien avec les membres du bureau <br>
            - réunion avec tous les membres de l'association <br>
            - paiement de la cotisation( renouvellemnt annuel)</p>
     </ul>


     <?php include "./footer.php"?>
</body>
</html>